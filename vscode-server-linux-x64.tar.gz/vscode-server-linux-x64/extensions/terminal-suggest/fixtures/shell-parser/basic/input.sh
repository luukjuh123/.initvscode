### Case 1
a b\\ c

### Case 2
a "b"

### Case 3
a 'b'

### Case 4
a $'b'

### Case 5
a $commit

### Case 6
a $$

### Case 7
a $((b))

### Case 8
a $(b)

### Case 9
a \`b\`

### Case 10
a $(\`b\`)
