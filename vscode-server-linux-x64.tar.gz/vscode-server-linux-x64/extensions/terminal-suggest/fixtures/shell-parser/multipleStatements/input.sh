### Case 1
a && b

### Case 2
a || b

### Case 3
a | b

### Case 4
a |& b

### Case 5
(a; b)

### Case 6
(a; b;)

### Case 7
{a; b}

### Case 8
{a; b;}

### Case 9
a; b

### Case 10
a & b

### Case 11
a &; b

### Case 12
a ; b;

### Case 13
a && b || c

### Case 14
a && b | c

### Case 15
a | b && c

### Case 16
(a) | b && c