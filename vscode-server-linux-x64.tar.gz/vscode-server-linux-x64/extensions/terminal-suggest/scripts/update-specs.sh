node ./update-specs.js
