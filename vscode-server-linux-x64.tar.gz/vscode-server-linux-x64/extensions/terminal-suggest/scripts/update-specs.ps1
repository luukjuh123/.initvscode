node "$PSScriptRoot/update-specs.js"
