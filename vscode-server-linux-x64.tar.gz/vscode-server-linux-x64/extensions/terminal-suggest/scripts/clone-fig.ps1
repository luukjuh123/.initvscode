git clone https://github.com/withfig/autocomplete third_party/autocomplete
